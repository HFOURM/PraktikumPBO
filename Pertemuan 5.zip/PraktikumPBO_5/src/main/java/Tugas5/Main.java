/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas5;

/**
 *
 * @author Acer
 */
public class Main {
    public static void main(String[] args) {        
        // Membuat objek Kucing dan Anjing
        Kucing kucing1 = new Kucing("Gatot", "Oren");
        Anjing anjing1 = new Anjing("Heli", "Black  ");
        
        // Demonstrasi overriding method
        kucing1.tampilkanInfo();
        kucing1.suara();
                                                
        System.out.println(); // Spasi
        
        anjing1.tampilkanInfo();
        anjing1.suara();
    }
}