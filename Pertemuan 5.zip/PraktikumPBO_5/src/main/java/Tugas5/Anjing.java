/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas5;

/**
 *
 * @author Acer
 */
public class Anjing extends Hewan {
    private String ras;
    
    // Constructor Anjing
    public Anjing(String nama, String ras) {
        super(nama, "Anjing"); // Memanggil constructor kelas induk
        this.ras = ras;
    }
    
    // Overriding method tampilkanInfo()
    @Override
    public void tampilkanInfo() {
        System.out.println("INFO ANJING");
        super.tampilkanInfo(); // Memanggil method dari kelas induk
        System.out.println("Ras: " + ras);
    }
    
    // Overriding method suara()
    @Override
    public void suara() {
        System.out.println(nama + " bersuara: Guk! Guk!");
    }
}
