/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas5;

/**
 *
 * @author Acer
 */
public class MainKendaraan {
    public static void main(String[] args) {
        Mobil mobil = new Mobil();
        mobil.nama = "BMW";
        mobil.kecepatan = 300;
        mobil.jumlahPintu = 2;
        mobil.jumlahRoda = 4;
        mobil.bahanBakar = "Pertamax Turbo";
        mobil.tampilkanInfo();
       
        System.out.println();
        
        Helikopter Heli = new Helikopter();
        Heli.nama = "Apache";
        Heli.kecepatan = 293;
        Heli.maksKetinggian = 6400;
        Heli.isiPenumpang = 3;
        mobil.bahanBakar = "Aftur";
        Heli.tampilkanInfo();
    }
}
