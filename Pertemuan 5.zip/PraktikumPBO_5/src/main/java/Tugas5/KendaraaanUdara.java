/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas5;

/**
 *
 * @author Acer
 */
public class KendaraaanUdara extends Kendaraan {
    // Atribut khusus kendaraan darat
    int isiPenumpang;
    String bahanBakar;
    
    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Ini adalah kendaraan Udara. ");
        System.out.println("Isi Penumpang:  " + isiPenumpang);
        System.out.println("Nama Bahan Bakar:  " + bahanBakar);
    }
}
