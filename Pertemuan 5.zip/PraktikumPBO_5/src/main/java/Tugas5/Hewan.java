/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas5;

/**
 *
 * @author Acer
 */
public class Hewan {
    // Atribut yang diwariskan ke kelas turunan
    protected String nama;
    protected String jenis;
    
    // Constructor
    public Hewan(String nama, String jenis) {
        this.nama = nama;
        this.jenis = jenis;
    }
    
    // Method untuk info Hewan
    public void tampilkanInfo() {
        System.out.println("Nama: " + nama);
        System.out.println("Jenis: " + jenis);
    }
    
    // Method untuk suara hewan 
    public void suara() {
        System.out.println("Hewan mengeluarkan suara");
    }
} 
