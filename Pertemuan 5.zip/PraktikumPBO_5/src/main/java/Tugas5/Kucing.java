    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas5;

/**
 *
 * @author Acer
 */
public class Kucing extends Hewan {
    private String warnaBulu;
    
    // Constructor Kucing
    public Kucing(String nama, String warnaBulu) {
        super(nama, "Kucing"); // Memanggil constructor kelas induk
        this.warnaBulu = warnaBulu;
    }
    
    // Overriding method tampilkanInfo()
    @Override
    public void tampilkanInfo() {
        System.out.println("INFO KUCING");
        super.tampilkanInfo(); // Memanggil method dari kelas induk
        System.out.println("Warna Bulu: " + warnaBulu);
    }
    
    // Overriding method suara()
    @Override
    public void suara() {
        System.out.println(nama + " bersuara: Meong! Meong!");
    }
}
