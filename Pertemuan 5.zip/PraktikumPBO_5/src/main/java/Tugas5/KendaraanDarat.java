/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas5;

/**
 *
 * @author Acer
 */
public class KendaraanDarat extends Kendaraan {
    // Atribut khusus kendaraan darat
    int jumlahRoda;
    String bahanBakar;
    
    
    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Ini adalah kendaraan darat. ");
        System.out.println("Jumlah Roda:  " + jumlahRoda);
        System.out.println("Nama Bahan Bakar:  " + bahanBakar);
    }
}
