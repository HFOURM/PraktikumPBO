/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package praktikum5;

/**
 *
 * @author Acer
 */
public class Kendaraan {
    // Atribut
    String nama;
    int kecepatan;
    
    public void tampilkanInfo(){
        System.out.println("Nama :" + nama);
        System.out.println("Kecepatan: " + kecepatan + "Km/jam");
    }
}
