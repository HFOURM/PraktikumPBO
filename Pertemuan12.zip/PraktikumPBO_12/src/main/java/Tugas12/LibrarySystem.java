/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas12;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Acer
 */
public class LibrarySystem {
    private static final String TEXT_FILE  = "buku.txt";
    private static final String SERIAL_FILE = "buku.ser";
    private static List<Buku> bukuList = new ArrayList<>();
    
    public static void main(String [] agrs) { 
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Tambah Buku");
            System.out.println("2. Simpan ke File Teks");
            System.out.println("3. Simpan Objek ke File (Serialiasi)");
            System.out.println("4. Tampilkan Dari File Teks");
            System.out.println("5. Tampilkan Dari File (Serialiasi)");
            System.out.println("6. Keluar");
            System.out.println("Pilihan: ");
            int pilihan = scanner.nextInt();
            scanner.nextLine(); 
            
            switch (pilihan) {
                case 1 -> tambahBuku(scanner);
                case 2 -> simpanKeFileTeks();
                case 3 -> simpanKeFileSerial();
                case 4 -> tampilkanDariFileTeks();
                case 5 -> tampilkanDariFileSerialiasi();
                case 6 -> {
                    System.out.println("Keluar dari sistem.");
                    scanner.close();
                    return;
                }
                default -> System.out.println("Pilihan tidak valid.");
            }
        }
    }
    
    private static void tambahBuku(Scanner scanner) {
        System.out.println("Masukkan Nama Buku: ");
        String judul = scanner.nextLine();
        System.out.println("Masukkan Nama Pengarang: ");
        String pengarang = scanner.nextLine();
        System.out.println("Masukkan Tahun Terbit: ");
        int tahunTerbit = scanner.nextInt();
        
        bukuList.add(new Buku(judul, pengarang, tahunTerbit));
        System.out.println("Buku berhasil ditambahkan.");
    }
    
    private static void simpanKeFileTeks() {
        try (FileWriter writer = new FileWriter(TEXT_FILE)) {
            for (Buku buku : bukuList) {
                writer.write(buku.toString() + "\n");
            }
            System.out.println("Data buku berhasil disimpan ke file teks.");
        } catch (IOException e) {
            System.out.println("Terjadi kesalahan saat menyimpan ke file teks.");
            e.printStackTrace();
        }
    }
    
    private static void simpanKeFileSerial() {
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(SERIAL_FILE))) {
            oos.writeObject(bukuList);
            System.out.println("Objek produk berhasil disimpan ke file serial.");
        } catch (IOException e) {
            System.out.println("Terjadi kesalahan saat meyimpan ke file serial.");
            e.printStackTrace();
        }
    }
    
    private static void tampilkanDariFileTeks() {
        System.out.println("Daftar Buku dari buku.txt :");
        try (BufferedReader reader = new BufferedReader(new FileReader(TEXT_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Tidak dapat membaca buku.txt");
            e.printStackTrace();
        }
    }
    
    private static void tampilkanDariFileSerialiasi() {
        System.out.println("Daftar Buku dari buku.txt :");
        try (BufferedReader reader = new BufferedReader(new FileReader(SERIAL_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Tidak dapat membaca buku.txt");
            e.printStackTrace();
        }
    }
}