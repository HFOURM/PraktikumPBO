/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Tugas3;

/**
 *
 * @author Acer
 */
public class Main {
    public static void main(String[] args){
        Mobil mobil1 = new Mobil("BMW","M4", 2012, "Hitam");
        Mobil mobil2 = new Mobil("Toyota","Supra", 2020, "Biru");
        System.out.println("Informasi Mobil 1:");
        mobil1.displayInfo();
        mobil1.startEngine();
        System.out.println();
        System.out.println("Mengubah warna Mobil 1");
        mobil1.gantiWarna("Merah");
        mobil1.displayInfo();
        System.out.println();
        System.out.println("Informasi Mobil 2:");
        mobil2.displayInfo();
        mobil2.startEngine();
        
    }
}
