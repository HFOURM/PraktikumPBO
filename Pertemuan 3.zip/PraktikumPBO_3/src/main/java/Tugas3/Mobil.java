/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas3;

/**
 *
 * @author Acer
 */
public class Mobil {
   private String merek;
   private String model;
   private int tahun;
   private String warna;
   
   public Mobil(String merek, String model, int tahun, String warna){
       this.merek = merek;
       this.model = model;
       this.tahun = tahun;
       this.warna = warna;
   }
   public String getMerek(){
       return merek;
   }
   public void setMerek(String merek){
       this.merek = merek;
   }
   public String getModel(){
       return model;
   }
   public void setModel(String model){
       this.model = model;
   }
   public int getTahun(){
       return tahun;
   }
   public void setTahun(int tahun){
       this.tahun = tahun;
   }
    void displayInfo(){
        System.out.println("Merek: "+ merek);
        System.out.println("Model: "+ model);
        System.out.println("Tahun: "+ tahun);
        System.out.println("Warna: "+ warna);
    }
    void startEngine(){
       System.out.println("Mesin mobil "+ merek +" menyala");
   }
    void gantiWarna(String warnaBaru){
        this.warna = warnaBaru;
        System.out.println("Warna mobil diubah menjadi "+ warnaBaru);
    }
}   
