/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas6;

/**
 *
 * @author Acer
 */
public class Main {
    public static void main(String[] agrs) {
        KeranjangBelanja keranjang = new KeranjangBelanja();
    
    // Membuat produk
    Buku buku = new Buku("Buku untuk Hadoop", 200000);
    Elektronik mouse = new Elektronik("Mouse Logitech", 899000);
    Pakaian baju = new Pakaian("Hem Berkerah", 150000);
    
    // Tambah ke keranjang
    keranjang.tambahProduk(buku);
    keranjang.tambahProduk(mouse);
    keranjang.tambahProduk(baju);
    
    // Tampilkan produk
    keranjang.tampilkanSemuaProduk();
    
    // Hitung total harga setelah diskon
    System.out.println("Total harga setelah diskon: Rp" + keranjang.hitungTotalHarga());
    }    
}
