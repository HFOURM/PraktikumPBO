/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas6;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Acer
 */
public class KeranjangBelanja {
    private List<Produk> daftarProduk;
    
    public KeranjangBelanja() {
        daftarProduk = new ArrayList<>();
    }
    
    public void tambahProduk(Produk produk){
        daftarProduk.add(produk);
    }
    
    public double hitungTotalHarga(){
        double total = 0;
        for (Produk p : daftarProduk){
            total += (p.harga - p.hitungDiskon());
        }
        return total;
    }
    
    // Method tambahan untuk menampilkan produk di keranjang
    public void tampilkanSemuaProduk() {
        System.out.println("DAFTAR PRODUK DALAM KERANJANG");
    
        if (daftarProduk.isEmpty()) {
            System.out.println("Keranjang belanja kosong!");
            return;
        }
        
        for (int i = 0; i < daftarProduk.size(); i++) {
            Produk p = daftarProduk.get(i);
            double diskon = p.hitungDiskon();
            
            System.out.println((i + 1) + ". " + p.nama);
            System.out.println("   Harga Asli: Rp" + p.harga);
            System.out.println("   Diskon: Rp" + diskon);
            System.out.println();
        }   
    }
}