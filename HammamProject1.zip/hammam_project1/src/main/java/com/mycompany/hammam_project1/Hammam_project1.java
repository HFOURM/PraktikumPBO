/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hammam_project1;

/**
 *
 * @author Acer
 */
public class Hammam_project1 {

    public static void main(String[] args) {
        System.out.println("Nama    : Hammam Al Rosyid M");
        System.out.println("NPM     : 2420506018");
        System.out.println("Alamat  : Mertoyudan, Magelang ");
        System.out.println("No_HP   : 085010101010");
    }
}
