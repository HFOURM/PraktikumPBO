/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package responsiuas;
import java.io.Serializable;

/**
 *
 * @author Acer
 */
public abstract class KoleksiBuku implements Serializable {
    protected String judul;
    
    public KoleksiBuku(String judul) {
        this.judul = judul;
    }
    
    public abstract void tampilkanInfo();
}
