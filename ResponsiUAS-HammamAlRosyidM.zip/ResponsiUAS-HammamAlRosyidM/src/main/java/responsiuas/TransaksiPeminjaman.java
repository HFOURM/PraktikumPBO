/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package responsiuas;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Acer
 */
public class TransaksiPeminjaman implements LayananPeminjaman, Serializable {
    private Anggota anggota;
    private List<Buku> bukuDipinjam = new ArrayList<>();

    public TransaksiPeminjaman(Anggota anggota) {
        this.anggota = anggota;
    }

    @Override
    public void pinjam(Buku buku) {
        buku.setDipinjam(true);
        bukuDipinjam.add(buku);
    }

    @Override
    public void kembalikan(Buku buku) {
        buku.setDipinjam(false);
        bukuDipinjam.remove(buku);
    }
}
