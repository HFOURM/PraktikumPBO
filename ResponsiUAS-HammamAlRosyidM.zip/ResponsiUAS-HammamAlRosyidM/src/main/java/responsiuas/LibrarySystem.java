/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package responsiuas;
import java.io.*;
import java.util.*;
/**
 *
 * @author Acer
 */

public class LibrarySystem {

    static List<Buku> daftarBuku = new ArrayList<>();
    static List<Anggota> daftarAnggota = new ArrayList<>();
    static List<TransaksiPeminjaman> transaksiList = new ArrayList<>();

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\nMENU PERPUSTAKAAN");
            System.out.println("1. Tambah Buku");
            System.out.println("2. Tambah Anggota");
            System.out.println("3. Tampilkan Buku");
            System.out.println("4. Tampilkan Anggota");
            System.out.println("5. Pinjam Buku");
            System.out.println("6. Simpan Data");
            System.out.println("7. Baca Data");
            System.out.println("8. Keluar");
            System.out.print("Pilih: ");

            try {
                int pilih = sc.nextInt();
                sc.nextLine();

                switch (pilih) {
                    case 1 -> {
                        System.out.print("ID Buku: ");
                        String id = sc.nextLine();
                        System.out.print("Judul: ");
                        String judul = sc.nextLine();
                        daftarBuku.add(new Buku(id, judul));
                    }
                    case 2 -> {
                        System.out.print("ID Anggota: ");
                        String id = sc.nextLine();
                        System.out.print("Nama: ");
                        String nama = sc.nextLine();
                        daftarAnggota.add(new Anggota(id, nama));
                    }
                    case 3 -> {
                        if (daftarBuku.isEmpty()) {
                            System.out.println("Data buku kosong.");
                        } else {
                            daftarBuku.forEach(Buku::tampilkanInfo);
                        }
                    }
                    case 4 -> {
                        if (daftarAnggota.isEmpty()) {
                            System.out.println("Data anggota kosong.");
                        } else {
                            for (Anggota a : daftarAnggota) {
                                System.out.println(a.getIdAnggota() + " - " + a.getNama());
                            }
                        }
                    }
                    case 5 -> {
                        if (!daftarAnggota.isEmpty() && !daftarBuku.isEmpty()) {
                            TransaksiPeminjaman t =
                                    new TransaksiPeminjaman(daftarAnggota.get(0));
                            t.pinjam(daftarBuku.get(0));
                            transaksiList.add(t);
                            System.out.println("Buku berhasil dipinjam.");
                        } else {
                            System.out.println("Data anggota atau buku belum ada.");
                        }
                    }
                    case 6 -> simpan();
                    case 7 -> baca();
                    case 8 -> System.exit(0);
                    default -> System.out.println("Pilihan tidak valid.");
                }
            } catch (Exception e) {
                System.out.println("Input salah.");
                sc.nextLine();
            }
        }
    }

    static void simpan() {
        try (ObjectOutputStream oos =
                     new ObjectOutputStream(new FileOutputStream("data.ser"))) {
            oos.writeObject(daftarBuku);
            oos.writeObject(daftarAnggota);
            oos.writeObject(transaksiList);
            System.out.println("Data berhasil disimpan.");
        } catch (IOException e) {
            System.out.println("Gagal simpan data.");
        }
    }

    static void baca() {
        try (ObjectInputStream ois =
                     new ObjectInputStream(new FileInputStream("data.ser"))) {
            daftarBuku = (List<Buku>) ois.readObject();
            daftarAnggota = (List<Anggota>) ois.readObject();
            transaksiList = (List<TransaksiPeminjaman>) ois.readObject();
            System.out.println("Data berhasil dibaca.");
        } catch (Exception e) {
            System.out.println("Gagal baca data.");
        }
    }
}
