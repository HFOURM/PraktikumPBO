/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package responsiuas;
import java.io.Serializable;
/**
 *
 * @author Acer
 */
public class Anggota  implements Serializable {
    private final String idAnggota;
    private final String nama;

    public Anggota(String idAnggota, String nama) {
        this.idAnggota = idAnggota;
        this.nama = nama;
    }

    public String getIdAnggota() {
        return idAnggota;
    }

    public String getNama() {
        return nama;
    }

    public void tampilkanInfo() {
        System.out.println(idAnggota + " | " + nama);
    }
}
