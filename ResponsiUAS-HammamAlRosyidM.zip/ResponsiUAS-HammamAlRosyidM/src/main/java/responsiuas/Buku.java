/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package responsiuas;

/**
 *
 * @author Acer
 */
public class Buku extends KoleksiBuku {
    private final String idBuku;
    private boolean dipinjam;

    public Buku(String idBuku, String judul) {
        super(judul);
        this.idBuku = idBuku;
        this.dipinjam = false;
    }

    public String getIdBuku() {
        return idBuku;
    }

    public boolean isDipinjam() {
        return dipinjam;
    }

    public void setDipinjam(boolean dipinjam) {
        this.dipinjam = dipinjam;
    }

    @Override
    public void tampilkanInfo() {
        System.out.println(idBuku + " | " + judul + " | " +
                (dipinjam ? "Dipinjam" : "Tersedia"));
    }
}
