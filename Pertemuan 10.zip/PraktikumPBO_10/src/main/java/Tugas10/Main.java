/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas10;

/**
 *
 * @author Acer
 */
public class Main {
    
    public static void main(String[] args) {
        //Objek Elektronik
        hitungPajak laptop = new Elektronik();
        System.out.println("Harga Elektronik : " + "12000000.0");
        System.out.println("Pajak Elektronik : " + laptop.pajak(12000000));
        System.out.println("Harga setelah pajak : " + laptop.harga(12000000));
        System.out.println("");
        //Objek Makanan
        hitungPajak roti = new Makanan();
        System.out.println("Harga Makanan :" + "13000.0");
        System.out.println("Pajak Makanan : " + roti.pajak(13000));
        System.out.println("Harga setelah pajak : " + roti.harga(13000));
    }
}