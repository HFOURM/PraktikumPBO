/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas10;

/**
 *
 * @author Acer
 */
public class Elektronik implements hitungPajak {
    @Override
    public double harga(double harga_brng) {
        return harga_brng + (harga_brng * 0.10); // 0.10 atau 10 % adalah pajaknya.
    }
    
    @Override
    public double pajak(double harga_brng) { 
        return harga_brng * 0.10; 
    }
}