/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Tugas10;

/**
 *
 * @author Acer
 */
public interface hitungPajak {
    // Untuk menampilkan harga barang setelah dipajak
    double harga(double harga_brng);
    // Untuk menampilakn harga pajak dari yang di pajak 
    double pajak(double harga_brng);
   
}