/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas10;

/**
 *
 * @author Acer
 */
public class Makanan implements hitungPajak{
    @Override
    public double harga(double harga_brng) {
        return harga_brng + (harga_brng * 0.05); // 0.05 atau 5 % adalah pajaknya.
    }
    
    @Override
    public double pajak(double harga_brng) {
        return harga_brng * 0.05; 
    }
}