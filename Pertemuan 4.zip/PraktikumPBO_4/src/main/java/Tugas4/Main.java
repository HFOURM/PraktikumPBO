/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas4;

/**
 *
 * @author Acer
 */
public class Main {
        
    public static void main(String[] args){
        // Membuat Objek Pekerja
        Pekerja p1 = new Pekerja("Hakkan",24,"Pengusaha",250000000);
        
        // Menampilkan info menggunakan metode toString().
        System.out.println(p1.toString());
        
        // Ubah nama menggunakan Method Setter
        p1.setNama("Mayza");
        
        // Menampilkan info setalah perubahan
        System.out.println("\nSetelah nama diubah:");
        System.out.println(p1.toString());
        
        // Mencoba akses langsung
        //System.out.println(p1.nama); // Error karena Akses Modifier Private
        System.out.println(p1.usia);
        System.out.println(p1.pekerjaan);
        //System.out.println(p1.gaji); // Error karena Akses Modifier Private
    }
}
