/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum4;

/**
 *
 * @author Acer
 */
public class Kendaraan {
    //Atribut dengan akses modifer berbeda
    private String nama;           // Hanya bisa diakess dalam kelas ini
    protected int kecepatanMaks;       // Bisa diakses di package yang sama dan subclass
    public String jenisMesin;      // Bisa diakes dari mana saja
    
    // Construktor
    public Kendaraan(String nama, int kecepatanMaks, String jenisMesin) {
        this.nama = nama;
        this.kecepatanMaks = kecepatanMaks;
        this.jenisMesin = jenisMesin; 
    }
    // Getter dan Setter untuk variable private nama
    public String getNama() {
        return nama;
    }
    public void setNama(String nama) {
        this.nama = nama;
    }
    // Method public untuk menampilakn informasi kendaraan
    public void tampilkanInformasiKendaraan(){
        System.out.println("Nama Kendaraan: " + nama);
        System.out.println("Kecepatan Maksimum: " + kecepatanMaks);
        System.out.println("Jenis Mesin: " + jenisMesin);
    }
}
