/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package praktikum4;

/**
 *
 * @author Acer
 */
public class PraktikumPBO_4 {

    public static void main(String[] args) {
        Mobil mobil1 = new Mobil("BMW",300 ,"V6",2);
        mobil1.tampilkanInfoMobil();
    }
}
